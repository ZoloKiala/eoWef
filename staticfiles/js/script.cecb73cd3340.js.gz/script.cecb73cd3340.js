$(document).ready(function(){
    $('#table').DataTable({
        "order": [[ 0, "desc" ]]
    });
    
    $('[data-toggle="tooltip"]').tooltip();



});

